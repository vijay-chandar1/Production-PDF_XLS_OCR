from .keywords import I_NOTE

FREE_RESOURCES = I_NOTE
